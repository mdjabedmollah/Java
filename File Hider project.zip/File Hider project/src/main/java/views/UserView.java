//package views;
//
//import dao.DataDAO;
//import model.Data;
//
//import java.io.File;
//import java.io.IOException;
//import java.sql.SQLException;
//import java.util.List;
//import java.util.Scanner;
//
//public class UserView {
//    private String email;
//
//    UserView(String email) {
//        this.email = email;
//    }
//
//    public void home() {
//        do {
//            System.out.println("Wlcome " + this.email);
//            System.out.println("Press 1 to show hidden files");
//            System.out.println("Press 2 to hide a new file");
//            System.out.println("Press 3 to unhide a file");
//            System.out.println("Press 0 to exit");
//            Scanner sc = new Scanner(System.in);
//            int ch = Integer.parseInt(sc.nextLine());
//            switch (ch) {
//                case 1 -> {
//                    try {
//                        List<Data> files = DataDAO.getAllFiles(this.email);
//                        System.out.println("ID - File Name");
//                        for (Data file : files) {
//                            System.out.println(file.getId() + " - " + file.getFileName());
//                        }
//                    } catch (SQLException e) {
//                        e.printStackTrace();
//                    }
//                }
//                case 2 -> {
//                    System.out.println("Enter the file path");
//                    String path = sc.nextLine();
//                    File f = new File(path);
//                    Data file = new Data(0, f.getName(), path, this.email);
//                    try {
//                        DataDAO.hideFile(file);
//                    } catch (SQLException e) {
//                        e.printStackTrace();
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                }
//                case 3 -> {
//                    List<Data> files = null;
//                    try {
//                        files = DataDAO.getAllFiles(this.email);
//
//                        System.out.println("ID - File Name");
//                        for (Data file : files) {
//                            System.out.println(file.getId() + " - " + file.getFileName());
//                        }
//                        System.out.println("Enter the id of file to unhide");
//                        int id = Integer.parseInt(sc.nextLine());
//                        boolean isValidID = false;
//                        for (Data file : files) {
//                            if (file.getId() == id) {
//                                isValidID = true;
//                                break;
//                            }
//                        }
//                        if (isValidID) {
//                            DataDAO.unhide(id);
//                        } else {
//                            System.out.println("Wrong ID");
//                        }
//                    } catch (SQLException  e) {
//                        e.printStackTrace();
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                }
//                case 0 -> {
//                    System.exit(0);
//                }
//            }
//        } while (true);
//    }
//}
package views;

import dao.DataDAO;
import model.Data;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class UserView {
    private String email;
    private JFrame frame;

    public UserView(String email) {
        this.email = email;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("User Home");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        JLabel welcomeLabel = new JLabel("Welcome, " + this.email, SwingConstants.CENTER);
        frame.add(welcomeLabel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new GridLayout(4, 1, 10, 10));

        JButton showHiddenFilesButton = new JButton("Show Hidden Files");
        JButton hideFileButton = new JButton("Hide a New File");
        JButton unhideFileButton = new JButton("Unhide a File");
        JButton exitButton = new JButton("Exit");

        buttonPanel.add(showHiddenFilesButton);
        buttonPanel.add(hideFileButton);
        buttonPanel.add(unhideFileButton);
        buttonPanel.add(exitButton);

        frame.add(buttonPanel, BorderLayout.CENTER);

        showHiddenFilesButton.addActionListener(e -> showHiddenFiles());
        hideFileButton.addActionListener(e -> hideFile());
        unhideFileButton.addActionListener(e -> unhideFile());
        exitButton.addActionListener(e -> System.exit(0));

        frame.setVisible(true);
    }

    private void showHiddenFiles() {
        try {
            List<Data> files = DataDAO.getAllFiles(this.email);
            StringBuilder fileList = new StringBuilder("ID - File Name\n");
            for (Data file : files) {
                fileList.append(file.getId()).append(" - ").append(file.getFileName()).append("\n");
            }
            JOptionPane.showMessageDialog(frame, fileList.toString(), "Hidden Files", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            showErrorDialog("Error fetching hidden files: " + e.getMessage());
        }
    }

    private void hideFile() {
        String path = JOptionPane.showInputDialog(frame, "Enter the file path", "Hide File", JOptionPane.PLAIN_MESSAGE);
        if (path != null && !path.isEmpty()) {
            File f = new File(path);
            Data file = new Data(0, f.getName(), path, this.email);
            try {
                DataDAO.hideFile(file);
                JOptionPane.showMessageDialog(frame, "File hidden successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (SQLException | IOException e) {
                showErrorDialog("Error hiding file: " + e.getMessage());
            }
        }
    }

    private void unhideFile() {
        try {
            List<Data> files = DataDAO.getAllFiles(this.email);
            StringBuilder fileList = new StringBuilder("ID - File Name\n");
            for (Data file : files) {
                fileList.append(file.getId()).append(" - ").append(file.getFileName()).append("\n");
            }
            String input = JOptionPane.showInputDialog(frame, fileList.toString() + "\nEnter the ID of the file to unhide", "Unhide File", JOptionPane.PLAIN_MESSAGE);
            if (input != null && !input.isEmpty()) {
                int id = Integer.parseInt(input);
                boolean isValidID = files.stream().anyMatch(file -> file.getId() == id);
                if (isValidID) {
                    DataDAO.unhide(id);
                    JOptionPane.showMessageDialog(frame, "File unhidden successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    showErrorDialog("Invalid file ID.");
                }
            }
        } catch (SQLException | IOException e) {
            showErrorDialog("Error unhiding file: " + e.getMessage());
        }
    }

    private void showErrorDialog(String message) {
        JOptionPane.showMessageDialog(frame, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        new UserView("user@example.com");
    }

    public void home() {
    }
}

