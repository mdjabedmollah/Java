//package views;
//
//import dao.UserDAO;
//import model.User;
//import service.GenerateOTP;
//import service.SendOTPService;
//import service.UserService;
//
//import java.io.BufferedReader;
//import java.io.IOException;
//import java.io.InputStreamReader;
//import java.sql.SQLException;
//import java.util.Scanner;
//
//public class Welcome {
//    public void welcomeScreen() {
//        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
//        System.out.println("Wlcome to the app");
//        System.out.println("Press 1 to login");
//        System.out.println("Press 2 to signup");
//        System.out.println("Press 0 to exit");
//        int choice = 0;
//        try {
//            choice = Integer.parseInt(br.readLine());
//        } catch (IOException ex) {
//            ex.printStackTrace();
//        }
//        switch (choice) {
//            case 1 -> login();
//            case 2 -> signUp();
//            case 0 -> System.exit(0);
//        }
//    }
//
//    private void login() {
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter email");
//        String email = sc.nextLine();
//        try {
//            if(UserDAO.isExists(email)) {
//                String genOTP = GenerateOTP.getOTP();
//                SendOTPService.sendOTP(email, genOTP);
//                System.out.println("Enter the otp");
//                String otp = sc.nextLine();
//                if(otp.equals(genOTP)) {
//                   new UserView(email).home();
//
//                } else {
//                    System.out.println("Wrong OTP");
//                }
//            } else {
//                System.out.println("User not found");
//            }
//        } catch (SQLException ex) {
//            ex.printStackTrace();
//        }
//
//    }
//    private void signUp() {
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter name");
//        String name = sc.nextLine();
//        System.out.println("Enter email");
//        String email = sc.nextLine();
//        String genOTP = GenerateOTP.getOTP();
//        SendOTPService.sendOTP(email, genOTP);
//        System.out.println("Enter the otp");
//        String otp = sc.nextLine();
//        if(otp.equals(genOTP)) {
//            User user = new User(name, email);
//            int response = UserService.saveUser(user);
//            switch (response) {
//                case 0 -> System.out.println("User registered");
//                case 1 -> System.out.println("User already exists");
//            }
//        } else {
//            System.out.println("Wrong OTP");
//        }
//
//    }
//}
package views;

import dao.UserDAO;
import model.User;
import service.GenerateOTP;
import service.SendOTPService;
import service.UserService;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class WelcomeGUI {
    private JFrame frame;

    public WelcomeGUI() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Welcome to the App");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        JLabel welcomeLabel = new JLabel("Welcome to the App", SwingConstants.CENTER);
        frame.add(welcomeLabel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new GridLayout(3, 1, 10, 10));

        JButton loginButton = new JButton("Login");
        JButton signUpButton = new JButton("Sign Up");
        JButton exitButton = new JButton("Exit");

        buttonPanel.add(loginButton);
        buttonPanel.add(signUpButton);
        buttonPanel.add(exitButton);

        frame.add(buttonPanel, BorderLayout.CENTER);

        loginButton.addActionListener(e -> login());
        signUpButton.addActionListener(e -> signUp());
        exitButton.addActionListener(e -> System.exit(0));

        frame.setVisible(true);
    }

    private void login() {
        String email = JOptionPane.showInputDialog(frame, "Enter email", "Login", JOptionPane.PLAIN_MESSAGE);
        if (email != null && !email.isEmpty()) {
            try {
                if (UserDAO.isExists(email)) {
                    String genOTP = GenerateOTP.getOTP();
                    SendOTPService.sendOTP(email, genOTP);
                    String otp = JOptionPane.showInputDialog(frame, "Enter the OTP", "OTP Verification", JOptionPane.PLAIN_MESSAGE);

                    if (otp != null && otp.equals(genOTP)) {
                        frame.dispose();
                        new UserView(email);
                    } else {
                        JOptionPane.showMessageDialog(frame, "Wrong OTP", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "User not found", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException ex) {
                showErrorDialog("Error during login: " + ex.getMessage());
            }
        }
    }

    private void signUp() {
        JTextField nameField = new JTextField();
        JTextField emailField = new JTextField();
        Object[] message = {
                "Name:", nameField,
                "Email:", emailField
        };

        int option = JOptionPane.showConfirmDialog(frame, message, "Sign Up", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String name = nameField.getText();
            String email = emailField.getText();

            if (!name.isEmpty() && !email.isEmpty()) {
                String genOTP = GenerateOTP.getOTP();
                SendOTPService.sendOTP(email, genOTP);

                String otp = JOptionPane.showInputDialog(frame, "Enter the OTP", "OTP Verification", JOptionPane.PLAIN_MESSAGE);

                if (otp != null && otp.equals(genOTP)) {
                    User user = new User(name, email);
                    int response = UserService.saveUser(user);
                    switch (response) {
                        case 0 -> JOptionPane.showMessageDialog(frame, "User registered successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                        case 1 -> JOptionPane.showMessageDialog(frame, "User already exists", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Wrong OTP", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Name and Email cannot be empty", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void showErrorDialog(String message) {
        JOptionPane.showMessageDialog(frame, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        new WelcomeGUI();
    }
}
